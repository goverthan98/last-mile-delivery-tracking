package dmSystem;
import GUI.GuiLogin;

public class DeliverySystem {

	public static void main(String[] args) {
		GuiLogin login = new GuiLogin();
		
	}

}
