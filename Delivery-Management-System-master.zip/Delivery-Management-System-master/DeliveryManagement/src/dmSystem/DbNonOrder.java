package dmSystem;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DbNonOrder extends Db{

	
	@Override
    public boolean insert(String [] data ){
		try {
			SimpleDateFormat format = new SimpleDateFormat ("yyyy-MM-dd");
			Date parsed = format.parse(data[9]);
			java.sql.Date sqlDate = new java.sql.Date(parsed.getTime());
		
		    preparedStatement = connect.prepareStatement("INSERT INTO `mydatabase`.`standingorder_walkin` (`DeliveryNumber`, `CustomerName`, `CustomerPhone`, `CustomerAddress`, `RecipientName`, `RecipientPhone`, `RecipientAddress`, `Item`, `Weight`, `Status`, `DeliveryDate`) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		    preparedStatement.setString(1, data[0]);
		    preparedStatement.setString(2, data[1]);
	        preparedStatement.setString(3, data[2]);
		    preparedStatement.setString(4, data[3]);
		    preparedStatement.setString(5, data[4]);
		    preparedStatement.setString(6, data[5]);
		    preparedStatement.setString(7, data[6]);
		    preparedStatement.setDouble(8, Double.parseDouble(data[7]));
		    preparedStatement.setString(9, data[8]);
		    preparedStatement.setDate(10, sqlDate);
		    preparedStatement.execute();
		    preparedStatement.close();
		   
		    return true;
		}
	 	catch (Exception E){
	    	E.printStackTrace();
	 	}
		    return false;
    }
    
    public ResultSet resultset() {
		   ResultSet rs = null;
	    try {
		  
	       rs = statement.executeQuery("SELECT * FROM standingorder_walkin");
		
		}
	    catch (Exception E){
  	      E.printStackTrace();
	    }
	   	  return rs;
	}
    
    public int getWalkInDeliveryNumber(){
		int walkindeliverynumber = 0;
		try {
			preparedStatement = connect.prepareStatement("SELECT MAX(DeliveryNumber) as ID FROM `standingorder_walkin` ");
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()){
				walkindeliverynumber = resultSet.getInt("ID");
			}
		}
		catch (Exception E){
	    	E.printStackTrace();
	 	}
		return walkindeliverynumber;
	}

	@Override
	public boolean update(String[] data) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(String[] data) {
		// TODO Auto-generated method stub
		return false;
	}
}
